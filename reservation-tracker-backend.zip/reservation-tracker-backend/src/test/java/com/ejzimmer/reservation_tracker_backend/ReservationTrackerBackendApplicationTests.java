package com.ejzimmer.reservation_tracker_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservationTrackerBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
