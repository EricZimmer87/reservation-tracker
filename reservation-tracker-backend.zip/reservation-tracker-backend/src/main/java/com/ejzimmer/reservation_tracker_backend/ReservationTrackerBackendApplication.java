package com.ejzimmer.reservation_tracker_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReservationTrackerBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReservationTrackerBackendApplication.class, args);
	}

}
